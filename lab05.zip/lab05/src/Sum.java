import java.util.ArrayList;
import java.util.List;

public class Sum extends Node {

    List<Node> args = new ArrayList<>();

    Sum(){}
    Sum(Node n) {
    //    if (!n.isZero()) {
            args.add(n);
    //    }
    }
    Sum(Node n1, Node n2){
     //   if (!n1.isZero())
            args.add(n1);
      //  if (!n2.isZero())
            args.add(n2);
    }


    Sum add(Node n){
        if (n != null && !n.isZero()) {
            args.add(n);
        }
        return this;
    }

    Sum add(double c){
        if(c!=0) {
            args.add(new Constant(c));
        }
            return this;
    }

    Sum add(double c, Node n) {
        if (c != 0) {
            Node mul = new Prod(c, n);
            args.add(mul);
        }
        return this;
    }

    @Override
    double evaluate() {
        double result =0;
        //oblicz sumę wartości zwróconych przez wywołanie evaluate skłądników sumy
        for (Node arg : args) {
            result += arg.evaluate();
        }
        return sign*result;
    }

    int getArgumentsCount(){return args.size();}

    @Override
    Node diff(Variable var) {
        Sum r = new Sum();
        for(Node n : args){
            r.add(n.diff(var));
        }
        return r;
    }

    @Override
    boolean isZero() {
        for (Node arg : args) {
            if (!arg.isZero()) {
                return false;
            }
        }
        return true;
    }

    public String toString(){

        if (args.isEmpty()) {
            return new Constant(0).toString();
        } else if (args.size() == 1) {
            return args.get(0).toString();
        }

        StringBuilder b =  new StringBuilder();
        if(sign<0)b.append("-(");

        for (int i =0; i<getArgumentsCount(); i++){


            if(i>0){
                b.append(sign >0 ? "+" : "-");
            }
            b.append(args.get(i).toString());

        }
        if(sign<0)b.append(")");


        return b.toString();

    }
   /* Node simplify() {
        List<Node> simplifiedArgs = new ArrayList<>();
        double constant = 1.0;
        for (Node arg : args) {
            if (arg instanceof Constant) {
                constant *= arg.evaluate();
            } else {
                simplifiedArgs.add(arg);
            }
        }

        if (constant != 1.0) {
            simplifiedArgs.add(new Constant(constant));
        }

        if (simplifiedArgs.isEmpty()) {
            return new Constant(0);
        } else if (simplifiedArgs.size() == 1) {
            return simplifiedArgs.get(0);
        } else {
            args = simplifiedArgs;
            return this;
        }
    }

    */



}