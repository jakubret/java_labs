import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.*;
import java.util.function.Supplier;

public class AsyncMean {
    static double[] array;

    static void initArray(int size) {
        array = new double[size];
        for (int i = 0; i < size; i++) {
            array[i] = Math.random() * size / (i+1);
        }
    }

    static class MeanCalcSupplier implements Supplier<Double> {
        private final int start;
        private final int end;

        MeanCalcSupplier(int start, int end) {
            this.start = start;
            this.end = end;
        }

        @Override
        public Double get() {
            double sum = 0;
            for (int i = start; i < end; i++) {
                sum += array[i];
            }
            double mean = sum / (end - start);
            System.out.printf(Locale.US, "%d-%d mean=%f\n", start, end, mean);
            return mean;
        }
    }

    public static void asyncMeanv1( int n) {
        int size = 100_000_000;
        initArray(size);
        ExecutorService executor = Executors.newFixedThreadPool(16);

        int dif = array.length / n;
        // Utwórz listę future
        List<CompletableFuture<Double>> partialResults = new ArrayList<>();
        for (int i = 0, start = 0; i < n; i++, start += dif) {
            CompletableFuture<Double> partialMean = CompletableFuture.supplyAsync(
                    new MeanCalcSupplier(start, start + dif), executor);
            partialResults.add(partialMean);
        }
        // zagreguj wyniki
        double mean=0;
        for(var pr:partialResults){
            // wywołaj pr.join() aby odczytać wartość future;
            // join() zawiesza wątek wołający
            pr.join();
        }
        System.out.printf(Locale.US,"mean=%f\n",mean);

        executor.shutdown();
    }


    public static void asyncMeanv2(int n) {
        int size = 100_000_000;
        initArray(size);
        ExecutorService executor = Executors.newFixedThreadPool(16);

        int dif = array.length / n;
        BlockingQueue<Double> queue = new ArrayBlockingQueue<>(n);

        for (int i = 0, start = 0; i < n; i++, start += dif) {
            CompletableFuture.supplyAsync(
                            new MeanCalcSupplier(start, start + dif), executor)
                    .thenAcceptAsync(queue::offer, executor);
        }

        // Poczekaj na zakończenie wszystkich zadań
        executor.shutdown();
        try {
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Pobierz wyniki z kolejki i oblicz średnią
        double mean = 0;
        for (int i = 0; i < n; i++) {
            try {
                mean += queue.take();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        mean /= n;
        System.out.printf(Locale.US, "mean=%f\n", mean);
    }

    public static void main(String[] args) {
        int size = 100_000_000;
        initArray(size);

       asyncMeanv1(10);
        asyncMeanv2(10);
    }
}
