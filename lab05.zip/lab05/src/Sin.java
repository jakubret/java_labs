class Sin extends Node {
    private Node argument;

    Sin(Node arg) {
        this.argument = arg;
    }

    @Override
    double evaluate() {
        return Math.sin(argument.evaluate());
    }

    @Override
    Node diff(Variable var) {
        return new Prod(new Cos(argument), argument.diff(var));
    }

    @Override
    boolean isZero() {
        return Math.abs(argument.evaluate()) < 0.0001;
    }

    @Override
    public String toString() {
        return "sin(" + argument.toString() + ")";
    }
}