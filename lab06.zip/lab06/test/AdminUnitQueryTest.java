import org.junit.Test;

import java.io.IOException;

public class AdminUnitQueryTest {
//wiecej testw nie robilem poniewaz nie czyta polskich znakow
    @Test
    public void startsWithK(){
        AdminUnitList adminUnitList = new AdminUnitList();
        try {
            adminUnitList.read("C:\\Users\\Acer Nitro 5\\IdeaProjects\\lab06\\admin-units.csv");
        } catch (IOException e) {
            e.printStackTrace();
        }
        adminUnitList.filter(a->a.name.startsWith("K")).sortInplaceByArea().list();
    }

    @Test
    public void test1(){
        AdminUnitList adminUnitList = new AdminUnitList();
        try {
            adminUnitList.read("C:\\Users\\Acer Nitro 5\\IdeaProjects\\lab06\\admin-units.csv");
        } catch (IOException e) {
            e.printStackTrace();
        }
        AdminUnitQuery query = new AdminUnitQuery()
                .selectFrom(adminUnitList)
                .where(a->a.area>500)
                .or(a->a.name.startsWith("Sz"))
                .sort((a,b)->Double.compare(a.area,b.area))
                .limit(24);

        AdminUnitList result = query.execute();
        result.list();
    }


    @Test
    public void test2(){
        AdminUnitList adminUnitList = new AdminUnitList();
        try {
            adminUnitList.read("C:\\Users\\Acer Nitro 5\\IdeaProjects\\lab06\\admin-units.csv");
        } catch (IOException e) {
            e.printStackTrace();
        }
        AdminUnitQuery query = new AdminUnitQuery().selectFrom(adminUnitList).where(a->a.population == 0)
                .or(a->a.density == 0).sort((a,b) -> Double.compare(a.area, b.area)).
                and(a->a.name.startsWith("K"));

        AdminUnitList result = query.execute();
        result.list();

    }

}