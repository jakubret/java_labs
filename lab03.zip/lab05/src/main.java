import java.util.Locale;

public class main {

    static void buildAndPrint(){
        Variable x = new Variable("x");
        Node exp = new Sum()
                .add(2.1,new Power(x,3))
                .add(new Power(x,2))
                .add(-2,x)
                .add(7);
        System.out.println(exp.toString());

    }

    static void buildAndEvaluate() {
        Variable x = new Variable("x");
        Node exp = new Sum()
                .add(new Power(x, 3))
                .add(-2, new Power(x, 2))
                .add(-1, x)
                .add(2);
        for (double v = -5; v < 5; v += 0.1) {
            x.setValue(v);
            System.out.printf(Locale.US, "f(%f)=%f\n", v, exp.evaluate());
        }
    }

    static void defineCircle(){
            Variable x = new Variable("x");
            Variable y = new Variable("y");
            Node circle = new Sum()
                    .add(new Power(x,2))
                    .add(new Power(y,2))
                    .add(8,x)
                    .add(4,y)
                    .add(16);
            System.out.println(circle.toString());

            double xv = 100*(Math.random()-.5);
            double yv = 100*(Math.random()-.5);
            x.setValue(xv);
            y.setValue(yv);
            double fv = circle.evaluate();
            System.out.print(String.format("Punkt (%f,%f) leży %s koła %s",xv,yv,(fv<0?"wewnątrz":"na zewnątrz"),circle.toString()));
        }

    static void findPointsInsideCircle() {
        Variable x = new Variable("x");
        Variable y = new Variable("y");
        Node circle = new Sum()
                .add(new Power(x, 2))
                .add(new Power(y, 2))
                .add(8, x)
                .add(4, y)
                .add(16);

        int wSrodku = 0;
        int doZnalezienia = 100;

        while (wSrodku < doZnalezienia) {
            double xv = 100 * (Math.random() - 0.5);
            double yv = 100 * (Math.random() - 0.5);

            x.setValue(xv);
            y.setValue(yv);

            double fv = circle.evaluate();

            if (fv < 0) {
                System.out.println(String.format("punktow w srodku (%f,%f) ", xv, yv));
                wSrodku++;
            }
        }
    }



        //Pochodne
    static void diffPoly() {
        Variable x = new Variable("x");
        Node exp = new Sum()
                .add(2,new Power(x,3))
                .add(new Power(x,2))
                .add(-2,x)
                .add(7);
        System.out.print("exp=");
        System.out.println(exp.toString());

        Node d = exp.diff(x);
        System.out.print("d(exp)/dx=");
        System.out.println(d.toString());

    }

    static void diffCircle() {
        Variable x = new Variable("x");
        Variable y = new Variable("y");
        Node circle = new Sum()
                .add(new Power(x,2))
                .add(new Power(y,2))
                .add(8,x)
                .add(4,y)
                .add(16);
        System.out.print("f(x,y)=");
        System.out.println(circle.toString());

        Node dx = circle.diff(x);
        System.out.print("d f(x,y)/dx=");
        System.out.println(dx.toString());
        System.out.print("d f(x,y)/dy=");
        Node dy = circle.diff(y);
        System.out.println(dy.toString());

    }
    static void funkcje() {
        Variable x = new Variable("x");

        // Test exp(x)
        Node expFunction = new Exp(x);
        System.out.println("Test dla exp(x):");

        for (double v = -5; v < 5; v += 0.1) {
            x.setValue(v);
            System.out.printf(Locale.US, "exp(%f)=%f\n", v, expFunction.evaluate());
        }

        // Test sin(x)
        Node sinFunction = new Sin(x);
        System.out.println("\nTest dla sin(x):");

        for (double v = -5; v < 5; v += 0.1) {
            x.setValue(v);
            System.out.printf(Locale.US, "sin(%f)=%f\n", v, sinFunction.evaluate());
        }

        // Test cos(x)
        Node cosFunction = new Cos(x);
        System.out.println("\nTest dla cos(x):");

        for (double v = -5; v < 5; v += 0.1) {
            x.setValue(v);
            System.out.printf(Locale.US, "cos(%f)=%f\n", v, cosFunction.evaluate());
        }
    }



    public static void main(String[] args) {

        diffPoly();
        diffCircle();
       // funkcje();
    }
}
