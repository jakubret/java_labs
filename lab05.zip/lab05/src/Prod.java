import java.util.ArrayList;
import java.util.List;

public class Prod extends Node {
    List<Node> args = new ArrayList<>();

    Prod(){}

    Prod(Node n1){
    //    if (!n1.isZero()) {
            args.add(n1);
    //    }
    }
    Prod(double c){
        args.add(new Constant(c));

    }

    Prod(Node n1, Node n2){
        args.add(n1);
        args.add(n2);
    }
    Prod(double c, Node n){
        this(new Constant(c),n);
    }



    Prod mul(Node n){
  //      if(!n.isZero()) {
            args.add(n);
    //    }
        return this;
    }

    Prod mul(double c){
        if(c!=0) {
            args.add(new Constant(c));
        }
        return this;
    }


    @Override
    double evaluate() {
        double result =1;
        // oblicz iloczyn czynników wołąjąc ich metodę evaluate

        for (Node arg : args) {
            if (arg != null) {
                result *= arg.evaluate();
            }
        }


        return sign*result;
    }
    int getArgumentsCount(){return args.size();}

  //  @Override
  //  Node diff(Variable var) {
  //      return null;
  //  }

    @Override
    boolean isZero() {
        return this.evaluate() == 0;
    }


    public String toString(){
////
        Node simplified = this.simplify();

        if (simplified instanceof Constant) {
            return simplified.toString();
        }
        Prod simplifiedProd = (Prod) simplified;
        List<Node> args = simplifiedProd.args;

        if (args.isEmpty()) {
            return new Constant(0).toString();
        } else if (args.size() == 1) {
            return args.get(0).toString();
        }
////
        StringBuilder b =  new StringBuilder();
        if(simplifiedProd.sign<0)b.append("-");

        for(int i=0; i<simplifiedProd.getArgumentsCount(); i++) {

            if (i > 0) {
                b.append(simplifiedProd.sign > 0 ? "*" : "");
            }
            if(args.get(i).getSign()<0){
                b.append("(");
            }

            b.append(args.get(i).toString());
            if(args.get(i).getSign()<0){
                b.append(")");
            }
        }

        return b.toString();
    }

    Node diff(Variable var) {
        Sum r = new Sum();
        for(int i=0;i<args.size();i++){
            Prod m= new Prod();
            for(int j=0;j<args.size();j++){
                Node f = args.get(j);
                if(j==i)m.mul(f.diff(var));
                else m.mul(f);
            }
            r.add(m);
        }
        return r;
    }


    // ta metoda lekko upraszcza mnożenie ale przy ujemnych wartościach gubi nawiasy (do dopracowania).

    public Node simplify() {
        double constantResult = 1.0;
        Prod remainingArgs = new Prod();

        for (Node arg : args) {
            if (arg instanceof Constant) {
                constantResult *= ((Constant) arg).evaluate(); // Pomnóż przez stałą
            } else {
                remainingArgs.mul(arg); // Dodaj jako pozostałe argumenty
            }
        }

        if (constantResult != 1.0) {
            remainingArgs.mul(new Constant(constantResult)); // Pomnóż resztę argumentów przez wynikowy iloczyn stałych
        }

        if (remainingArgs.getArgumentsCount() == 0) {
            return new Constant(constantResult); // Jeśli nie ma żadnych pozostałych argumentów, zwróć iloczyn stałych
        } else if (remainingArgs.getArgumentsCount() == 1) {
            return remainingArgs.args.get(0); // Jeśli jest tylko jeden argument, zwróć go jako wynik
        }

        return remainingArgs; // Zwróć zaktualizowany iloczyn
    }







}