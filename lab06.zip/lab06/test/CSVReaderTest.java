import org.junit.Test;

import java.io.IOException;

public class CSVReaderTest {

    @Test
    public void testPliku1() throws IOException {
        CSVReader reader = new CSVReader("C:\\Users\\Acer Nitro 5\\IdeaProjects\\lab06\\with-header.csv", ";", true);
        while (reader.next()) {
            for (String label : reader.getColumnLabels()) {
                System.out.print(reader.get(label));
                System.out.print(" ");
            }
            System.out.println();
        }
    }
    @Test
    public void testPliku2() throws IOException {
        CSVReader reader = new CSVReader("C:\\Users\\Acer Nitro 5\\IdeaProjects\\lab06\\admin-units.csv", ";", true);
        while (reader.next()) {
            for (String label : reader.getColumnLabels()) {
                System.out.print(reader.get(label));
                System.out.print(" ");
            }
            System.out.println();
        }
    }

}