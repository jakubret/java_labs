package clockk;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.time.LocalTime;

public class ClockWithGui extends JPanel implements Runnable {

    private LocalTime time = LocalTime.now();



    public static void main(String[] args) {
        JFrame frame = new JFrame("clockk.Clock");
        ClockWithGui clock = new ClockWithGui();
        frame.setContentPane(clock);
        frame.setSize(700, 700);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(true);
        frame.setVisible(true);

        Thread clockThread = new Thread(clock);
        clockThread.start();
    }

    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);

        Graphics2D g2d=(Graphics2D)g;
        g2d.translate(getWidth()/2,getHeight()/2);


        g2d.setColor(Color.RED);
        g2d.fillOval(-126, -131, 255, 255);
        g2d.setColor(Color.WHITE);
        g2d.fillOval(-100, -100, 200, 200);
        for(int i=1;i<13;i++){
            g2d.setColor(Color.BLACK);
            AffineTransform at = new AffineTransform();
            at.rotate(2*Math.PI/12*i);
            Point2D src = new Point2D.Float(0,-120);
            Point2D trg = new Point2D.Float();
            at.transform(src,trg);
            g2d.drawString(Integer.toString(i),(int)trg.getX(),(int)trg.getY());
        }
        for (int i = 0; i < 60; i++) {
            g2d.rotate(Math.toRadians(6));
            g2d.setColor(Color.BLACK);
            AffineTransform saveAT = g2d.getTransform();

            int nowaPozycja = (i + 1) % 60;

            if (nowaPozycja % 5 == 0) {
                g2d.setStroke(new BasicStroke(2));
                g2d.drawLine(0, -95, 0, -100);
            } else {
                g2d.setStroke(new BasicStroke(1));
                g2d.drawLine(0, -98, 0, -100);
            }
            g2d.setTransform(saveAT);
        }
        AffineTransform saveAT = g2d.getTransform();
        g2d.rotate(time.getHour()%12*2*Math.PI/12);
        g2d.setStroke(new BasicStroke(3));
        g2d.drawLine(0,0,0,-50);
        g2d.setTransform(saveAT);

        g2d.rotate(time.getMinute() * 2 * Math.PI / 60);
        g2d.setStroke(new BasicStroke(2));
        g2d.drawLine(0, 0, 0, -75);
        g2d.setTransform(saveAT);

        g2d.setColor(Color.RED);
        g2d.rotate(time.getSecond() * 2 * Math.PI / 60);
        g2d.setStroke(new BasicStroke(1));
        g2d.drawLine(0, 0, 0, -85);
        g2d.setTransform(saveAT);
    }

    @Override
    public void run() {
        try {
            while (true) {
                time = LocalTime.now();
                repaint();
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
