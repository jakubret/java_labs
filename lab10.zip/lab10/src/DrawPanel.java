import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class DrawPanel extends JPanel {
    List<XmasShape> shapes = new ArrayList<>();

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (XmasShape s : shapes) {
            s.draw((Graphics2D) g);
        }
    }

    DrawPanel(){
        setBackground(new Color(148, 179, 234));
//        setOpaque(true);


        //    shapes.add(new Bucket(10,400));
        //    shapes.add(new Bucket(400,10));
        //    shapes.add(new Bucket(10,10));
        //    shapes.add(new Bucket(400,400));

    }

}