import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class Section {
    String title;
    List<Paragraph> paragraps = new ArrayList<>() ;

    Section(){}
    Section setTitle(String title1){
        this.title = title1;
        return this;
    }
    Section addParagraph(String paragraphText){
        Paragraph paragrr = new Paragraph(paragraphText);
        paragraps.add(paragrr);
        return this;
    }
    Section addParagraph(Paragraph p){
        paragraps.add(p);
        return this;
    }
    void writeHTML(PrintStream out){
        out.printf("<section>\n");
        out.printf("<h2>%s</h2>\n", title);

        for(Paragraph p : paragraps){
            p.writeHTML(out);
        }
        out.printf("</section>");
    }


}
