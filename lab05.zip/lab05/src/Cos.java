class Cos extends Node {
    private Node argument;

    Cos(Node arg) {
        this.argument = arg;
    }

    @Override
    double evaluate() {
        return Math.cos(argument.evaluate());
    }

    @Override
    Node diff(Variable var) {
        return new Prod(new Sin(argument).minus(), argument.diff(var));
    }

    @Override
    boolean isZero() {
        return Math.abs(argument.evaluate()) < 0.0001;
    }

    @Override
    public String toString() {
        return "cos(" + argument.toString() + ")";
    }
}