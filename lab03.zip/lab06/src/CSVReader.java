import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CSVReader {
    BufferedReader reader;
    String delimiter;
    boolean hasHeader;

    // nazwy kolumn w takiej kolejności, jak w pliku
    List<String> columnLabels = new ArrayList<>();
    // odwzorowanie: nazwa kolumny -> numer kolumny
    Map<String, Integer> columnLabelsToInt = new HashMap<>();

    /**
     * @param filename  - nazwa pliku
     * @param delimiter - separator pól
     * @param hasHeader - czy plik ma wiersz nagłówkowy
     */

    public CSVReader(String filename, String delimiter, boolean hasHeader) throws IOException {
        reader = new BufferedReader(new FileReader(filename));
        this.delimiter = delimiter;
        this.hasHeader = hasHeader;
        if (hasHeader) parseHeader();
    }

    CSVReader(String filename, String delimiter) throws FileNotFoundException {
        this.delimiter = delimiter;
        reader = new BufferedReader(new FileReader(filename));

    }

    CSVReader(String filename) throws FileNotFoundException {
        reader = new BufferedReader(new FileReader(filename));
    }

    public CSVReader(Reader reader, String delimiter, boolean hasHeader) {
        this.delimiter = delimiter;
        this.hasHeader = hasHeader;
        this.reader = new BufferedReader(reader);
        if (hasHeader) {
            try {
                parseHeader();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }




    void parseHeader() throws IOException {
        String line = reader.readLine();
        if (line == null) {
            return;
        }
        String[] header = line.split(delimiter);
        for (int i = 0; i < header.length; i++) {
            columnLabels.add(header[i]);
            columnLabelsToInt.put(header[i], i);

        }
    }


    String[] current;

    boolean next() throws IOException {
        // czyta następny wiersz, dzieli na elementy i przypisuje do current
        //
        String line = reader.readLine();

        if (line != null) {
            current = line.split(delimiter);
            return true;
        }
        return false;

    }


    List<String> getColumnLabels(){
        return columnLabels;
    }

    int getRecordLength(){

            return current.length;

    }

    boolean isMissing(int columnIndex) {
        if (current != null && columnIndex >= 0 && columnIndex < current.length) {
            return current[columnIndex].isEmpty();
        }

        return true;
    }


    boolean isMissing(String columnLabel) {
        Integer columnIndex = columnLabelsToInt.get(columnLabel);
        if(columnIndex==null)
            return true;
        return isMissing(columnIndex);
    }



    String get(int column) {
        if(isMissing(column))
            return "";
        return current[column];
    }

    String get(String column){
        if(isMissing(column))
            return "";
        return current[columnLabelsToInt.get(column)];
    }

    int getInt(int columnIndex) throws Exception {
        if(isMissing(columnIndex)){
            throw new Exception ("bladbladblad");
        }
        else{
            return Integer.parseInt(current[columnIndex]);
        }
    }

    int getInt(String columnLabel) throws Exception {
        if(isMissing(columnLabel)){
            throw new Exception ("bladbladblad");
        }
        return getInt(columnLabelsToInt.get(columnLabel));
    }

    long getLong(int columnIndex) throws Exception {
        if (isMissing(columnIndex)){
            throw new Exception ("bladbladblad");
        }
        return Long.parseLong(current[columnIndex]);
    }
    long getLong(String columnLabel) throws Exception {
        if (isMissing(columnLabel)){
            throw new Exception ("bladbladblad");
        }
        return getLong(columnLabelsToInt.get(columnLabel));
    }

    double getDouble(int columnIndex) throws Exception {
        if(isMissing(columnIndex)){
            throw new Exception ("bladbladblad");
        }
        return Double.parseDouble(current[columnIndex]);
    }

    double getDouble(String columnLabel) throws Exception {
        if(isMissing(columnLabel)){
            throw new Exception ("bladbladblad");
        }
        return getDouble(columnLabelsToInt.get(columnLabel));
    }

    LocalTime getTime(int columnIndes, String format){
        return LocalTime.parse(current[columnIndes], DateTimeFormatter.ofPattern(format));
    }

    LocalDate getDate(int columnIndes, String format){
        return LocalDate.parse(current[columnIndes], DateTimeFormatter.ofPattern(format));
    }
    LocalDateTime getDateTime(int columnIndes, String format){
        return LocalDateTime.parse(current[columnIndes], DateTimeFormatter.ofPattern(format));
    }




}
