import java.io.PrintStream;

public class Photo {
    Photo(String url) {
        this.url = url;
    }

    String url;

    void writeHTML(PrintStream out) {
        out.print("<div style=\"text-align:center;\">\n");
        out.printf("<img src=\"%s\" alt=\"Smiley face\" height=\"150\" width=\"180\"/>\n", url);
        out.print("</div>\n");
    }
}
