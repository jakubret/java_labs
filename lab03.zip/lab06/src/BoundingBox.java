public class BoundingBox {
    double xmin ;
    double ymin ;
    double xmax ;
    double ymax ;
    boolean isEmpty = true;
    /**
     * Powi�ksza BB tak, aby zawiera� punkt (x,y)
     * Je�eli by� wcze�niej pusty - w�wczas ma zawiera� wy��cznie ten punkt
     * @param x - wsp�rz�dna x
     * @param y - wsp�rz�dna y
     */

    void addPoint(double x, double y){
        if(isEmpty){
            xmin = x;
            xmax = x;
            ymin = y;
            ymax = y;
            isEmpty=false;
        }
        else {
            if (x < xmin)
                xmin = x;
            if( x > xmax)
                xmax = x;
            if(y < ymin)
                ymin = y;
            if(y > ymax)
                ymax = y;
        }
    }

    /**
     * Sprawdza, czy BB zawiera punkt (x,y)
     * @param x
     * @param y
     * @return
     */
    boolean contains(double x, double y){
    //    if(x>xmin && x < xmax && y< ymax && y>ymin)
    //        return true;
    //    else
    //        return false;
        return (x>xmin && x < xmax) && (y< ymax && y>ymin);
    }

    /**
     * Sprawdza czy dany BB zawiera bb
     * @param bb
     * @return
     */
    boolean contains(BoundingBox bb){
        return (bb.xmin>xmin && bb.xmax < xmax) && (bb.ymax< ymax && bb.ymin>ymin);
    }

    /**
     * Sprawdza, czy dany BB przecina si� z bb
     * @param bb
     * @return
     */
    boolean intersects(BoundingBox bb){
        return (!(bb.xmax < xmin)) && (!(bb.xmin > xmax)) && (!(bb.ymax < ymin)) && (!(bb.ymin > ymax));
    }
    /**
     * Powi�ksza rozmiary tak, aby zawiera� bb oraz poprzedni� wersj� this
     * Je�eli by� pusty - po wykonaniu operacji ma by� r�wny bb
     * @param bb
     * @return
     */
    BoundingBox add(BoundingBox bb){
        if(bb.xmax > xmax)
            xmax = bb.xmax;
        if(bb.xmin < xmin)
            xmin = bb.xmin;
        if(bb.ymin < ymin)
            bb.ymin = ymin;
        if(bb.ymax > ymax)
            ymax=bb.ymax;
        return this;
    }
    /**
     * Sprawdza czy BB jest pusty
     * @return
     */
   // boolean isEmpty(){
  //      return xmin == 0.0 && ymin == 0.0 && xmax == 0.0 && ymax == 0.0;
   // }

    /**
     * Sprawdza czy
     * 1) typem o jest BoundingBox
     * 2) this jest r�wny bb
     * @return
     */
    public boolean equals(Object o){
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BoundingBox bb = (BoundingBox) o;
        return Double.compare(bb.xmin, xmin) == 0 &&
                Double.compare(bb.ymin, ymin) == 0 &&
                Double.compare(bb.xmax, xmax) == 0 &&
                Double.compare(bb.ymax, ymax) == 0;
    }

    /**
     * Oblicza i zwraca wsp�rz�dn� x �rodka
     * @return if !isEmpty() wsp�rz�dna x �rodka else wyrzuca wyj�tek
     * (sam dobierz typ)
     */
    double getCenterX(){
        if(!isEmpty)
            return (xmax + xmin)/2;
        else
            throw new RuntimeException("Not implemented");
    }
    /**
     * Oblicza i zwraca wsp�rz�dn� y �rodka
     * @return if !isEmpty() wsp�rz�dna y �rodka else wyrzuca wyj�tek
     * (sam dobierz typ)
     */
    double getCenterY(){
        if(!isEmpty)
            return (ymax + ymin)/2;
        else
            throw new RuntimeException("Not implemented");
    }

    /**
     * Oblicza odleg�o�� pomi�dzy �rodkami this bounding box oraz bbx
     * @param bbx prostok�t, do kt�rego liczona jest odleg�o��
     * @return if !isEmpty odleg�o��, else wyrzuca wyj�tek lub zwraca maksymaln� mo�liw� warto�� double
     * Ze wzgl�du na to, �e s� to wsp�rz�dne geograficzne, zamiast odleg�o�ci u�yj wzoru haversine
     * (ang. haversine formula)
     *
     * Gotowy kod mo�na znale�� w Internecie...
     */
    double distanceTo(BoundingBox bbx) {
        if (!isEmpty && !bbx.isEmpty) {
            double centerX = getCenterX();
            double centerY = getCenterY();
            double centerX1 = bbx.getCenterX();
            double centerY1 = bbx.getCenterY();

            double dLat = Math.toRadians(centerX - centerX1);
            double dLon = Math.toRadians(centerY - centerY1);

            centerX = Math.toRadians(centerX);
            centerX1 = Math.toRadians(centerX1);

            double a = Math.pow(Math.sin(dLat / 2), 2) +
                    Math.pow(Math.sin(dLon / 2), 2) *
                            Math.cos(centerX) *
                            Math.cos(centerX1);
            double rad = 6371;
            double c = 2 * Math.asin(Math.sqrt(a));
            return rad * c;
        } else {
            throw new IllegalArgumentException("Pusto");
        }
    }

    public String toString() {
        return String.format("BoundingBox [xmin=%f, ymin=%f, xmax=%f, ymax=%f]",
                xmin, ymin, xmax, ymax);
    }
}