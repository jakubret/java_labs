import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class ParagraphWithList extends Paragraph {
   // String content11;
    UnorderedList unorderedList;

   ParagraphWithList(){
       super();
       this.unorderedList = new UnorderedList();
   }
  /*  ParagraphWithList(String content11){
        super(content11);
        this.unorderedList = new UnorderedList();
    }

   */
    ParagraphWithList setContent(String newContent){
        super.setContent(newContent);
        return this;
}
 ParagraphWithList addItemToList(String newitems){
     unorderedList.addItem(new ListItem(newitems));
     return this;
}
    void writeHTML(PrintStream out){
        super.writeHTML(out);
        unorderedList.writeHTML(out);
    }

}
