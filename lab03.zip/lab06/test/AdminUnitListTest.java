import org.junit.Test;

import java.io.IOException;
import java.util.Locale;
// nie wczytuje polskich znak�w
public class AdminUnitListTest {
    @Test
    public void test1() throws IOException {
        CSVReader reader = new CSVReader("C:\\Users\\Acer Nitro 5\\IdeaProjects\\lab06\\admin-units.csv", ",", true);
        int counter = 0;
        while (reader.next()) {
            if(counter == 100){
                break;
            }
            int admin_level;
            try {
                admin_level = reader.getInt("admin_level");
            } catch (Exception e) {
                admin_level = 0;
            }

            String name = reader.get("name");
            double population;
            try {
                population = reader.getDouble("population");
            } catch (Exception e) {
                population = 0.0;
            }

            System.out.printf("admin_level: %d, Name: %s, population: %.2f%n", admin_level, name, population);
            counter += 1;
        }
    }
    @Test
    public void testPierwszy() throws IOException{
        AdminUnitList ul = new AdminUnitList();
        ul.read("C:\\Users\\Acer Nitro 5\\IdeaProjects\\lab06\\admin-units.csv");
    }

    @Test
    public void testDrugi() throws IOException{
        AdminUnitList adminUnitList = new AdminUnitList();
        adminUnitList.read("C:\\Users\\Acer Nitro 5\\IdeaProjects\\lab06\\admin-units.csv");
        AdminUnitList result = adminUnitList.selectByName(".*cki.*");
        result.list(System.out, 0, 15);
    }

    @Test
    public void �uromin() throws IOException{
        AdminUnitList adminUnitList = new AdminUnitList();
        adminUnitList.read("C:\\Users\\Acer Nitro 5\\IdeaProjects\\lab06\\admin-units.csv");
        AdminUnitList result = adminUnitList.selectByName(".*uromin.*");
        System.out.println(result.units.get(0).toString());
    }

    @Test
    public void sasiedzi�uromin() throws IOException{
        double t1 = System.nanoTime()/1e6;
        // wywo�anie funkcji
        AdminUnitList adminUnitList = new AdminUnitList();
        adminUnitList.read("C:\\Users\\Acer Nitro 5\\IdeaProjects\\lab06\\admin-units.csv");
        AdminUnitList result = adminUnitList.selectByName(".*uromin.*");
        if (!result.units.isEmpty()) {
            AdminUnit zuromin = result.units.get(0);
            System.out.println(zuromin.toString());
            AdminUnitList neighbours = adminUnitList.getNeighbours(zuromin, 15);

            for(AdminUnit unit : neighbours.units){
                System.out.println(unit.toString());
            }
        }
        double t2 = System.nanoTime()/1e6;
        System.out.println("Czas wyszukiwania : \n");
        System.out.printf(Locale.US,"t2-t1=%f\n",t2-t1);
    }
//nie wczytuje polskich znak�w :((
    @Test
    public void sasiedzi�urominGmina() throws IOException{
        double t1 = System.nanoTime()/1e6;
        // wywo�anie funkcji
        AdminUnitList adminUnitList = new AdminUnitList();
        adminUnitList.read("C:\\Users\\Acer Nitro 5\\IdeaProjects\\lab06\\admin-units.csv");
        AdminUnitList result = adminUnitList.selectByName("^gmina .*uromin.*");
        if (!result.units.isEmpty()) {
            AdminUnit gmina_zuromin = result.units.get(0);
            System.out.println(gmina_zuromin.toString());
            AdminUnitList neighbours = adminUnitList.getNeighbours(gmina_zuromin, 0);
            for(AdminUnit unit : neighbours.units){
                System.out.println(unit.toString());
            }
        }
        double t2 = System.nanoTime()/1e6;
        System.out.println("Czas wyszukiwania:");
        System.out.printf(Locale.US,"t2-t1=%f\n",t2-t1);
    }

    @Test
    public void testWojewdoztwa() throws IOException{
        double t1 = System.nanoTime()/1e6;
        // wywo�anie funkcji
        AdminUnitList adminUnitList = new AdminUnitList();
        adminUnitList.read("C:\\Users\\Acer Nitro 5\\IdeaProjects\\lab06\\admin-units.csv");
        AdminUnitList result = adminUnitList.selectByName(".*mazowieckie.*");
        if (!result.units.isEmpty()) {
            AdminUnit mazowieckie = result.units.get(0);
            System.out.println(mazowieckie.toString());
            AdminUnitList neighbours = adminUnitList.getNeighbours(mazowieckie, 20);

            for(AdminUnit unit : neighbours.units){
                System.out.println(unit.toString());
            }
        }
        double t2 = System.nanoTime()/1e6;
        System.out.println("Czas wyszukiwania: \n");
        System.out.printf(Locale.US,"t2-t1=%f\n",t2-t1);
    }

}