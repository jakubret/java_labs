class Exp extends Node {
    private Node argument;

    Exp(Node arg) {
        this.argument = arg;
    }

    @Override
    double evaluate() {
        return Math.exp(argument.evaluate());
    }

    @Override
    Node diff(Variable var) {
        return new Prod(this.argument.diff(var), new Exp(this.argument));
    }

    @Override
    boolean isZero() {
        return false;
    }

    @Override
    public String toString() {
        return "exp(" + argument.toString() + ")";
    }
}
