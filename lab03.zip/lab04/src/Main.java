import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Main {
    public static void main(String[] arg) throws FileNotFoundException, UnsupportedEncodingException {
        Document cv = new Document("Jeff Bezos");
        cv.setPhoto("https://i.insider.com/5c6f211726289831ce117cae?width=750&format=jpeg&auto=webp");
        cv.addSection("Wykształcenie")
                .addParagraph(new ParagraphWithList().setContent("My education history:")
                        .addItemToList("2006-2009 Przedszkole im. Królewny Snieżki")
                        .addItemToList("2009-2019 ZS2 w Żurominie")
                        .addItemToList("2019-2022 Liceum Ogołnokształcące im Stanisława Małachowskiego w Płocku")
                        .addItemToList("obecnie AGH"));

        cv.addSection("Umiejętności")
                .addParagraph(
                        new ParagraphWithList().setContent("Kursy")
                                .addItemToList("Języka Angielskiego")
                                .addItemToList("Języka Niemieckiego")
                                .addItemToList("Języka Ruskiego")
                );
        cv.addSection("Umiejętności")
                .addParagraph(
                        new ParagraphWithList().setContent("Znane technologie")
                                .addItemToList("C")
                                .addItemToList("C++")
                                .addItemToList("Java")
                                .addItemToList("Python")
                );
        cv.addSection("Zainteresowania")
                .addParagraph(
                        new ParagraphWithList().setContent("hobby ")
                                .addItemToList("pływanie")
                                .addItemToList("dobry film")
                                .addItemToList("dobra książka")
                );
        System.out.println(cv.toJson());
        try{
            cv.writeHTML(new PrintStream("cv1.html","UTF-8"));
        }
        catch(UnsupportedEncodingException e){ e.printStackTrace();}

        String jsonString = cv.toJson();

        String filePath = "output1.json";

        try {
            Files.write(Paths.get(filePath), jsonString.getBytes());
            System.out.println("JSON content saved to file: " + filePath);
        } catch (Exception e) {
            e.printStackTrace();
        }

}
}
