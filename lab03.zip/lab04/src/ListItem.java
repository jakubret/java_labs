import java.io.PrintStream;

public class ListItem {
    String content;
    ListItem(String content1){
        this.content=content1;
    }
    void writeHTML(PrintStream out){
        out.printf("<li>%s</li>\n", content);
    }
}
