import java.util.ArrayList;
import java.util.List;

public class AdminUnit {
    String name;
    int adminLevel;
    double population;
    double area;
    double density;
    AdminUnit parent;
    BoundingBox bbox = new BoundingBox();
    List<AdminUnit> children = new ArrayList<>();
    // ... metody ...


    @Override
    public String toString() {
        return name + "," + adminLevel + "," + population + "," + area + "," + density + "," + bbox.toString() + "\n";
    }


    public void fixMissingDensity() {
        if(parent!=null){
            if(parent.density != -1)
                this.density = parent.density;
            else
                parent.fixMissingDensity();
        }
        else{
            throw new IllegalCallerException("nie mo�na przypisa� density rodzica, poniewa� ten obiekt unit nie posiada rodzica");
        }
    }

    public void fixMissingPopulation() {
        population = area * density;
    }
}