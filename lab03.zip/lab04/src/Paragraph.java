import java.io.PrintStream;

public class Paragraph {
    String content2;
    Paragraph(){

    }
    Paragraph(String content){
        this.content2 = content;
    }

    Paragraph setContent(String newContent){
        content2 = newContent;
        return this;
    }
    void writeHTML(PrintStream out){
        out.printf("<p>%s</p>\n",content2);
    }
}
