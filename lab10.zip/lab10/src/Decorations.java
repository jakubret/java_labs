import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Decorations {
    List<XmasShape> decorations = new ArrayList<>();
    Random rand = new Random();

    Decorations() {
        this.generateLights();
        this.generateBubbles();
        this.generateStars();
    }
    private double generateRandomScale() {
        // Generates a random value between 0.20 and 0.35
        return 0.20 + (0.15 * rand.nextDouble());
    }
    private Color generateRandomColor() {
        int r = rand.nextInt(256); // Generates a random value from 0 to 255 for red
        int g = rand.nextInt(256); // Generates a random value from 0 to 255 for green
        int b = rand.nextInt(256); // Generates a random value from 0 to 255 for blue
        return new Color(r, g, b);
    }

    private void generateLights() {
        int[][] lightPositions = {
                // { x ,  y , i},
                {385, 130, 4},
                {360, 170, 9},
                {360, 210, 11},
                {330, 250, 15},
                {310, 300, 19},
                {290, 350, 26},
        };

        for (int[] position : lightPositions) {
            for (int i = 0; i < position[2]; i++) {
                Light light = new Light();
                light.x = position[0] + 10 * i;
                light.y = position[1] + 2 * i;
                light.fillColor = generateRandomColor();

                this.decorations.add(light);
            }
        }
    }
    private void generateStars() {
        int numOfStars = 1; // Number of stars to generate
        int[][] starPositions = {

                {400, 100},
        };

        for (int i = 0; i < numOfStars; i++) {
            Star star = new Star(
                    starPositions[i][0],
                    starPositions[i][1],
                    10, // Random radius between 10 and 30
                    generateRandomColor() // Random color
            );

            decorations.add(star);
        }
    }


    private void generateBubbles() {
        int[][] bubblePositions = {
                // { x ,  y },
                {378, 142},
                {350, 225},
                {420, 235},
                {309, 315},
                {392, 283},
                {458, 302},
                {470, 350},
                {392, 383},
                {280, 383},
        };

        for (int[] position : bubblePositions) {
            Bubble bubble = new Bubble();
            bubble.x = position[0];
            bubble.y = position[1];
            bubble.scale = generateRandomScale();
            bubble.fillColor = generateRandomColor();
            bubble.lineColor = Color.black;
            this.decorations.add(bubble);
        }
    }
}
