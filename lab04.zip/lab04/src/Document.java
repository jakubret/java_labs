import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.typeadapters.RuntimeTypeAdapterFactory;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class Document {
    String title;
    Photo photo;
    List<Section> sections = new ArrayList<>();

    public Document() {
    }

    Document(String title) {
        this.title = title;
    }

    Document setTitle(String title) {
        this.title = title;
        return this;
    }

    Document setPhoto(String photoUrl) {
        this.photo = new Photo(photoUrl);
        return this;
    }

    Section addSection(String sectionTitle) {
        Section secttion = new Section();
        secttion.setTitle(sectionTitle);
        sections.add(secttion);

        return secttion;
    }

    Document addSection(Section s) {
        sections.add(s);
        return this;
    }


    void writeHTML(PrintStream out) {
        // zapisz niezbędne znaczniki HTML
        // dodaj tytuł i obrazek
        // dla każdej sekcji wywołaj section.writeHTML(out)
        out.print("<!DOCTYPE html> \n");
        out.print("<html> \n");
        out.print("<head>\n");
        out.print("<style>\n");
        out.print("body {\n");
        out.print("    background-color: #e6ffe6;\n");
        out.print("}\n");
        out.print("</style>\n");
        out.printf("<title>" + title + "</title> \n");
        out.print("</head>\n");
        out.print("<body>\n");
        photo.writeHTML(out);
        for (Section section : sections) {
            section.writeHTML(out);
        }
        out.print("</body>\n" +
                "</html>");
    }

       String toJson(){
           Gson gson = new GsonBuilder().setPrettyPrinting().create();
           return gson.toJson(this);
       }

  /*  String toJson() {
        RuntimeTypeAdapterFactory<Paragraph> adapter =
                RuntimeTypeAdapterFactory
                        .of(Paragraph.class)
                        .registerSubtype(Paragraph.class)
                        .registerSubtype(ParagraphWithList.class);
        Gson gson = new GsonBuilder().registerTypeAdapterFactory(adapter).setPrettyPrinting().create();
        return gson.toJson(this);
    }

   */
}