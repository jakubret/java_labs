import java.util.Locale;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Mean {
    static double[] array;
    static BlockingQueue<Double> results = new ArrayBlockingQueue<>(100);

    static void initArray(int size) {
        array = new double[size];
        for (int i = 0; i < size; i++) {
            array[i] = Math.random() * size / (i + 1);
        }
    }

    static class MeanCalc extends Thread {
        private final int start;
        private final int end;
        double mean = 0;

        MeanCalc(int start, int end) {
            this.start = start;
            this.end = end;
        }

        public void run() {
            double sum = 0;
            for (int i = start; i < end; i++) {
                sum += array[i];
            }
            mean = sum / (end - start);
            try {
                results.put(mean);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.printf(Locale.US, "%d-%d mean=%f\n", start, end, mean);
        }
    }

    static void parallelMeanv1(int cnt) throws InterruptedException {
        MeanCalc[] threads = new MeanCalc[cnt];
        int bSize = array.length / cnt;

        for (int i = 0; i < cnt; i++) {
            int start = i * bSize;
            int end = Math.min((i + 1) * bSize, array.length);
            threads[i] = new MeanCalc(start, end);
            threads[i].start();
        }

        double t1 = System.nanoTime() / 1e6;

        for (MeanCalc mc : threads) {
            mc.join();
        }
        double t2 = System.nanoTime() / 1e6;

        double totalSum = 0;
        for (MeanCalc mc : threads) {
            totalSum += mc.mean;
        }
        double mean = totalSum / cnt;
        double t3 = System.nanoTime() / 1e6;

        System.out.printf(Locale.US, "size = %d cnt=%d >  t2-t1=%f t3-t1=%f mean=%f\n",
                array.length,
                cnt,
                t2 - t1,
                t3 - t1,
                mean);
    }

    static void parallelMeanv2(int cnt) throws InterruptedException {
        MeanCalc[] threads = new MeanCalc[cnt];
        int bSize = array.length / cnt;
        double t1 = System.nanoTime() / 1e6;

        for (int i = 0; i < cnt; i++) {
            int start = i * bSize;
            int end = Math.min((i + 1) * bSize, array.length);
            threads[i] = new MeanCalc(start, end);
            threads[i].start();
        }

        double t2 = System.nanoTime() / 1e6;


        double totalSum = 0;
        for (MeanCalc mc : threads) {
            totalSum += results.take();
        }
        double mean = totalSum / cnt;

        double t3 = System.nanoTime() / 1e6;

        System.out.printf(Locale.US, " 2 size = %d cnt=%d >  t2-t1=%f t3-t1=%f mean=%f\n",
                array.length,
                cnt,
                t2 - t1,
                t3 - t1,
                mean);
    }

    static void parallelMeanv3(int cnt) throws InterruptedException {
        ExecutorService executor = Executors.newFixedThreadPool(cnt);

        int bSize = array.length / cnt;

        double t1 = System.nanoTime() / 1e6;

        for (int i = 0; i < cnt; i++) {
            int start = i * bSize;
            int end = Math.min((i + 1) * bSize, array.length);
            executor.execute(new MeanCalc(start, end));
        }

        executor.shutdown();

        double t2 = System.nanoTime() / 1e6;

        double totalSum = 0;
        for (int i = 0; i < cnt; i++) {
            totalSum += results.take();
        }
        double mean = totalSum / cnt;


        double t3 = System.nanoTime() / 1e6;

        System.out.printf(Locale.US, " 3 size = %d cnt=%d >  t2-t1=%f t3-t1=%f mean=%f\n",
                array.length,
                cnt,
                t2 - t1,
                t3 - t1,
                mean);
    }

    public static void main(String[] args) throws InterruptedException {
        initArray(128000000);
         for(int cnt:new int[]{1,2,4,8,16,32,64,128}){
              parallelMeanv3(cnt);
          }

        //  AsyncMean.asyncMeanv2();
    }
}
