import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

import static org.junit.Assert.*;

public class DocumentTest {

    @Test
    public void writeHTML() {
        String title = "title";
        ByteArrayOutputStream dsa = new ByteArrayOutputStream();
        PrintStream asd = new PrintStream(dsa);
        Document document =  new Document(title);
        document.setPhoto("https://i.insider.com/5c6f211726289831ce117cae?width=750&format=jpeg&auto=webp");
        document.writeHTML(asd);

        String result = null;
        try{
            result = dsa.toString("UTF-8");
        }catch (UnsupportedEncodingException exception){
            exception.printStackTrace();
        }
        assertTrue(result.contains("<!DOCTYPE html"));
        assertTrue(result.contains("<html lang="));
        assertTrue(result.contains("<title>CV</title>"));
        assertTrue(result.contains("<head>"));
        assertTrue(result.contains("<meta charset=\"UTF-8\">"));
        assertTrue(result.contains("</head>"));
        assertTrue(result.contains("<h1>" + title + "</h1>"));
        assertTrue(result.contains("</body>" + "</html>"));

    }
}