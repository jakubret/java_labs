import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        System.out.println("wojew�dztwo ma�opolskie".matches(".*ma�op.*"));
        System.out.println("wojew�dztwo ma�opolskie".matches("^wojew.*"));
        System.out.println("wojew�dztwo pomorskie".matches(".*skie"));
        System.out.println("wojew�dztwo ma�opolskie".contains("ma�op"));
    }
}
