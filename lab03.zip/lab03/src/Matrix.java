


import java.util.Random;



    public class Matrix {
        double[] data;
        int rows;
        int cols;

        //...
        Matrix(int rows, int cols) {
            this.rows = rows;
            this.cols = cols;
            data = new double[rows * cols];
        }

        Matrix(double[][] d) {
            rows = d.length;
            cols = 0;
            for (double[] row : d) {
                if (row.length > cols) {
                    cols = row.length;
                }
            }
            data = new double[rows * cols];
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    if (j < d[i].length) {
                        data[i * cols + j] = d[i][j];
                    } else {
                        data[i * cols + j] = 0.0;
                    }
                }
            }
        }

        double get(int r, int c) {
            return data[r * cols + c];
        }

        void set(int r, int c, double value) {
            this.data[r * cols + c] = value;
        }

        double[][] asArray() {
            double[][] array = new double[rows][cols];
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    array[i][j] = data[i * cols + j];
                    ;
                }
            }
            return array;
        }

        public String toString() {
            StringBuilder buf = new StringBuilder();
            buf.append("[");
            for (int i = 0; i < rows; i++) {
                buf.append("[");
                for (int j = 0; j < cols; j++) {
                    buf.append(data[i * cols + j]);
                    if (j < cols - 1) {
                        buf.append(", ");
                    }
                }
                buf.append("]");
                if (i < rows - 1) {
                    buf.append(", ");
                }
            }
            buf.append("]");
            return buf.toString();
        }

        int[] shape() {
            int[] shape = {rows, cols};
            return shape;
        }

        void reshape(int newRows, int newCols) {
            if (rows * cols != newRows * newCols) {
                throw new RuntimeException(String.format("%d x %d matrix can't be reshaped to %d x %d", rows, cols, newRows, newCols));
            }

            double[] newData = new double[newRows * newCols];
            for (int i = 0; i < newRows; i++) {
                for (int j = 0; j < newCols; j++) {
                    if (i < rows && j < cols) {
                        newData[i * newCols + j] = data[i * cols + j];
                    } else {
                        newData[i * newCols + j] = 0.0;
                    }
                }
            }

            rows = newRows;
            cols = newCols;
            data = newData;
        }

        Matrix add(Matrix m) {
            if (rows != m.rows || cols != m.cols)
                throw new RuntimeException("inne rozmiary.");
            Matrix result = new Matrix(rows, cols);
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    result.data[i * cols + j] = this.data[i * cols + j] + m.data[i * cols + j];
                }
            }
            return result;
        }

        Matrix sub(Matrix m) {
            if (rows != m.rows || cols != m.cols)
                throw new RuntimeException("inne rozmiary.");
            Matrix result = new Matrix(rows, cols);
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    result.data[i * cols + j] = this.data[i * cols + j] - m.data[i * cols + j];
                }
            }
            return result;
        }

        Matrix mul(Matrix m) {
            if (cols != m.rows) {
                throw new RuntimeException("inne rozmiary.");
            }
            Matrix result = new Matrix(rows, m.cols);
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < m.cols; j++) {
                    double sum = 0;
                    for (int k = 0; k < cols; k++) {
                        sum += this.data[i * cols + k] * m.data[k * m.cols + j];
                    }
                    result.data[i * m.cols + j] = sum;
                }
            }
            return result;
        }

        Matrix div(double w) {
            Matrix result = new Matrix(rows, cols);
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    result.data[i * cols + j] = this.data[i * cols + j] / w;
                }
            }
            return result;
        }

        Matrix add(double w) {
            Matrix result = new Matrix(rows, cols);
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    result.data[i * cols + j] = this.data[i * cols + j] + w;
                }
            }
            return result;
        }
        Matrix sub(double w) {
            Matrix result = new Matrix(rows, cols);
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    result.data[i * cols + j] = this.data[i * cols + j] - w;
                }
            }
            return result;
        }
        Matrix mul(double w) {
            Matrix result = new Matrix(rows, cols);
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    result.data[i * cols + j] = this.data[i * cols + j] * w;
                }
            }
            return result;
        }
        Matrix dot(Matrix m) {
            if (cols != m.rows) {
                throw new IllegalArgumentException("inne rozmiary.");
            }
            Matrix result = new Matrix(this.rows, m.cols);
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < m.cols; j++) {
                    double sum = 0;
                    for (int k = 0; k < this.cols; k++) {
                        sum += this.data[i * this.cols + k] * m.data[k * m.cols + j];
                    }
                    result.data[i * m.cols + j] = sum;
                }
            }
            return result;

        }

        double frobenius() {
            double suma = 0.0;
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    double value = data[i * cols + j];
                    suma += value * value;
                }
            }
            return Math.sqrt(suma);
        }

        public static Matrix random(int rows, int cols) {
            Matrix m = new Matrix(rows, cols);
            Random r = new Random();
            m.set(0, 0, r.nextDouble());

            return m;
        }

        public static Matrix eye(int n) {
            Matrix m = new Matrix(n, n);
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (i == j) {
                        m.data[i * n + j] = 1.0;
                    } else {
                        m.data[i * n + j] = 0.0;
                    }
                }
            }
            return m;
        }
        public Matrix minor(int row, int column) {

            double[][] minor = new double[rows - 1][cols - 1];
            int minorRow = 0;
            for (int i = 0; i < rows; i++) {
                if (i == row) {
                    continue;
                }
                int minorColumn = 0;
                for (int j = 0; j < cols; j++) {
                    if (j == column) {
                        continue;
                    }
                    minor[minorRow][minorColumn] = data[i * cols + j];
                    minorColumn++;
                }
                minorRow++;
            }

            return new Matrix(minor);
        }

        public double wyznacznik() {
            if (rows != cols) {
                throw new IllegalArgumentException("macierze musza byc kwadratowe");
            }
            if (rows == 1) {
                return data[0];
            } else if (rows == 2) {
                return data[0] * data[3] - data[1] * data[2];
            } else {
                double wyz = 0.0;
                for (int j = 0; j < cols; j++) {
                    Matrix minorMatrix = minor(0, j);
                    double minorWyz = minorMatrix.wyznacznik();
                    wyz += data[j] * minorWyz * (j % 2 == 0 ? 1 : -1);
                }
                return wyz;
            }


        }


    public static void main(String[] args) {
        double[][] matrixData1 = {
                {2, 3, 1},
                {1, 2, 3},
                {3, 1, 2}
        };

        double[][] matrixData2 = {
                {7, 8},
                {9, 10},
                {11, 12},
        };

        Matrix matrix1 = new Matrix(matrixData1);
        Matrix matrix2 = new Matrix(matrixData2);
        double wyznacz = matrix1.wyznacznik();
        System.out.println("Wyznacznik: " + wyznacz);
        System.out.println("matrix 1");
        System.out.println(matrix1.toString());

        System.out.println("matrix 2");
        System.out.println(matrix2.toString());
        double[][] dwawymiar = matrix1.asArray();
        System.out.println("dwuwymiarowy");
        for (int i = 0; i < dwawymiar.length; i++) {
            for (int j = 0; j < dwawymiar[i].length; j++) {
                System.out.print(dwawymiar[i][j] + " ");
            }
            System.out.println();
        }
    }
}
