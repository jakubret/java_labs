import java.io.IOException;
import java.io.PrintStream;
import java.util.*;
import java.util.function.Predicate;

public class AdminUnitList {
    List<AdminUnit> units = new ArrayList<>();
    //private List<AdminUnit> adminUnits;
    public void read(String filename) throws IOException {
        Map<Long, AdminUnit> idToAdminUnit = new HashMap<>();
        Map<AdminUnit, Long> adminUnitToParentId = new HashMap<>();
        Map<Long, List<AdminUnit>> parentid2child = new HashMap<>();
        HashMap<AdminUnit, Long> unitToId = new HashMap<>();

        try {
            CSVReader reader = new CSVReader(filename, ",", true);

            while (reader.next()) {
                AdminUnit newUnit = new AdminUnit();

                newUnit.name = reader.get("name");

                try {
                    newUnit.population = reader.getDouble("population");
                } catch (Exception e) {
                    newUnit.population = 0;
                }

                try {
                    newUnit.adminLevel = reader.getInt("admin_level");
                } catch (Exception e) {
                    newUnit.adminLevel = 0;
                }



                try {
                    newUnit.area = reader.getDouble("area");
                } catch (Exception e) {
                    newUnit.area = 0;
                }

                try {
                    newUnit.density = reader.getDouble("density");
                } catch (Exception e) {
                    newUnit.density = 0;
                }

                long id;

                try {
                    id = reader.getLong("id");
                } catch (Exception e) {
                    id = 0;
                }

                long parentId;
                try {
                    parentId = reader.getLong("parent");
                } catch (Exception e) {
                    parentId = 0;
                }

                idToAdminUnit.put(id, newUnit);
                adminUnitToParentId.put(newUnit, parentId);
                unitToId.put(newUnit, id);
                if (parentId != 0) {
                    parentid2child.computeIfAbsent(parentId, k -> new ArrayList<>()).add(newUnit);
                }

                // Obs�uga b��d�w podczas czytania wsp�rz�dnych x i y dla bounding boxa
                BoundingBox boundingBox = new BoundingBox();
                try {
                    boundingBox.addPoint(reader.getDouble("x1"), reader.getDouble("y1"));
                    boundingBox.addPoint(reader.getDouble("x2"), reader.getDouble("y2"));
                    boundingBox.addPoint(reader.getDouble("x3"), reader.getDouble("y3"));
                    boundingBox.addPoint(reader.getDouble("x4"), reader.getDouble("y4"));
                } catch (Exception e) {
                    boundingBox.xmin = 0;
                    boundingBox.xmax = 0;
                    boundingBox.ymax = 0;
                    boundingBox.ymin = 0;
                }

                newUnit.bbox = boundingBox;
                units.add(newUnit);
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }

        for (AdminUnit ut : units) {
            long rodzic = adminUnitToParentId.get(ut);
            if (adminUnitToParentId.containsKey(ut)) {
                ut.parent = idToAdminUnit.getOrDefault(rodzic, null);
            }
            else {
                ut.parent = null;
            }
        }
        for(AdminUnit ut : units){
            List<AdminUnit> dzieci = parentid2child.getOrDefault(unitToId.get(ut),Collections.emptyList());
            ut.children.addAll(dzieci);
        }

        fixMissingValues();
    }

    /**
     * Wypisuje zawarto�� korzystaj�c z AdminUnit.toString()
     */
    void list(){
        for(AdminUnit element : units){
            System.out.print(element.toString());
        }
    }
    /**
     * Wypisuje co najwy�ej limit element�w pocz�wszy od elementu o indeksie offset
     * @param out - strumie� wyjsciowy
     * @param offset - od kt�rego elementu rozpocz�� wypisywanie
     * @param limit - ile (maksymalnie) element�w wypisa�
     */
    void list(PrintStream out, int offset, int limit) {
        int maxIndex = Math.min(offset + limit, units.size()); // Unikamy wyj�cia poza zakres listy

        for (int i = offset; i < maxIndex; i++) {
            out.println(units.get(i).toString()); // Ka�da jednostka w nowym wierszu
        }
    }

    /**
     * Zwraca now� list� zawieraj�c� te obiekty AdminUnit, kt�rych nazwa pasuje do wzorca
     *
     * @param pattern - wzorzec dla nazwy
     * @return podzbi�r element�w, kt�rych nazwy spe�niaj� kryterium wyboru
     */
    AdminUnitList selectByName(String pattern){
        AdminUnitList ret = new AdminUnitList();
        // przeiteruj po zawarto�ci units
        // je�eli nazwa jednostki pasuje do wzorca dodaj do ret
        for (AdminUnit element : units) {
            if (element.name.matches(pattern))
                ret.units.add(element);
        }
        return ret;
    }

    public AdminUnitList getNeighbours(AdminUnit unit, double maxdistance) {
        AdminUnitList result = new AdminUnitList();
        for (AdminUnit node : this.units) {
            if (node.adminLevel == unit.adminLevel && unit != node) {
                if (unit.adminLevel >= 8) {
                    if (unit.bbox.distanceTo(node.bbox) < maxdistance)
                        result.units.add(node);
                } else if (unit.bbox.intersects(node.bbox))
                    result.units.add(node);
            }
        }
        return result;
    }
    List<AdminUnit> getUnits(){
        return units;
    }

    public void fixMissingValues() {
        for (AdminUnit unit : units) {
            if (unit.density == 0 || unit.density == -1) {
                unit.fixMissingDensity();
            }
            if (unit.population == 0 || unit.population == -1) {
                unit.fixMissingPopulation();
            }
        }
    }


    /**
     * Zwraca list� jednostek s�siaduj�cych z jendostk� unit na tym samym poziomie hierarchii admin_level.
     * Czyli s�siadami wojwe�dztw s� wojew�dztwa, powiat�w - powiaty, gmin - gminy, miejscowo�ci - inne miejscowo�ci
     * @param unit - jednostka, kt�rej s�siedzi maj� by� wyznaczeni
     * @param maxdistance - parametr stosowany wy��cznie dla miejscowo�ci, maksymalny promie� odleg�o�ci od �rodka unit,
     *                    w kt�rym maj� sie znale�� punkty �rodkowe BoundingBox s�siad�w
     * @return lista wype�niona s�siadami
     */
    AdminUnitList getNeighbors(AdminUnit unit, double maxdistance){
        AdminUnitList result = new AdminUnitList();
        for (AdminUnit node : this.units) {
            if (node.adminLevel == unit.adminLevel && unit != node) {
                if (unit.adminLevel >= 8) {
                    if (unit.bbox.distanceTo(node.bbox) < maxdistance)
                        result.units.add(node);
                } else if (unit.bbox.intersects(node.bbox))
                    result.units.add(node);
            }
        }
        return result;
    }
    ////////////////-------/////////////
    AdminUnitList sortInplaceByName(){
        units.sort(new Comparator<AdminUnit>() {
            @Override
            public int compare(AdminUnit unit1, AdminUnit unit2) {
                return unit1.name.compareTo(unit2.name);
            }
        });

        return this;
    }

    public AdminUnitList sortInplaceByArea() {
        units.sort(new Comparator<AdminUnit>() {
            @Override
            public int compare(AdminUnit unit1, AdminUnit unit2) {
                // Compare by area (assuming area is a double field in AdminUnit class)
                return Double.compare(unit1.area, unit2.area);
            }
        });

        return this;
    }

    AdminUnitList sortInplaceByPopulation(){
        units.sort((AdminUnit a1,AdminUnit a2)->Double.compare(a1.population, a2.population));
        return this;
    }

    AdminUnitList sortInPlace(Comparator<AdminUnit> cmp){
        this.units.sort(cmp);
        return this;
    }
    AdminUnitList sort(Comparator<AdminUnit> cmp){
        AdminUnitList resultList = new AdminUnitList();
        resultList.units.addAll(units);
        return resultList.sortInPlace(cmp);
    }

    AdminUnitList filter(Predicate<AdminUnit> pred){
        AdminUnitList result = new AdminUnitList();
        for(AdminUnit node : units){
            if(pred.test(node))
                result.units.add(node);
        }
        return result;
    }


     AdminUnitList filter(Predicate<AdminUnit> p, int limit, int offset) {
        AdminUnitList result = new AdminUnitList();

        int i=0;
        for(AdminUnit node : units){
            if(p.test(node) && i < limit+offset) {
                if(i>=offset)
                    result.units.add(node);
                i++;
            }
            else if(i==limit + offset)
                break;
        }
        return result;
    }

}


