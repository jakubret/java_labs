import java.awt.*;
import java.awt.geom.Path2D;

public class Star implements XmasShape {
    private final Color color;
    private final int xOffset;
    private final int yOffset;
    private final double radius;
    private final Shape starShape;

    public Star(int x, int y, double radius, Color color) {
        xOffset = x;
        yOffset = y;
        this.color = color;
        this.radius = radius;
        starShape = createDefaultStar(radius);
    }

    @Override
    public void transform(Graphics2D g2d) {
        g2d.translate(xOffset, yOffset);
    }

    @Override
    public void render(Graphics2D g2d) {
        XmasShape.setGradientFill(g2d, (int) (radius * 2), color.brighter(), color);
        g2d.fill(starShape);
    }

    private Shape createDefaultStar(double radius) {
        return createStar(radius, radius * 2.63, Math.toRadians(-18));
    }

    /** @link https://stackoverflow.com/a/39808564    zaporzyczony kod do gwiazdki*/
    private Shape createStar(
            double innerRadius,
            double outerRadius,
            double startAngleRad) {
        Path2D path = new Path2D.Double();
        double deltaAngleRad = Math.PI / 5;
        for (int i = 0; i < 5 * 2; i++) {
            double angleRad = startAngleRad + i * deltaAngleRad;
            double ca = Math.cos(angleRad);
            double sa = Math.sin(angleRad);
            double relX = ca;
            double relY = sa;
            if ((i & 1) == 0) {
                relX *= outerRadius;
                relY *= outerRadius;
            } else {
                relX *= innerRadius;
                relY *= innerRadius;
            }
            if (i == 0) {
                path.moveTo((double) 0 + relX, (double) 0 + relY);
            } else {
                path.lineTo((double) 0 + relX, (double) 0 + relY);
            }
        }
        path.closePath();
        return path;
    }
}