import org.junit.Test;

import static org.junit.Assert.*;

public class MatrixTest {
@Test
    public void Matrix(){
    Matrix matrix = new Matrix(new double[][]{{1,2,3},{3,4,5},{7,8,9}});
    int rows = matrix.rows;
    int cols = matrix.cols;
    int expectedcols = 3;
    int expectedrows = 3;
    assertEquals(expectedcols,cols);
    assertEquals(expectedrows,rows);

    }
    @Test
    public void Testget() {
        Matrix matrix = new Matrix(new double[][]{{10,20},{33,44}});
        double e1 = matrix.get(0, 0);
        double e2 = matrix.get(0, 1);
        double e3 = matrix.get(1, 0);
        double e4 = matrix.get(1, 1);
        double delta = 1e-15;
        assertEquals(10, e1, delta);
        assertEquals(20, e2, delta);
        assertEquals(33, e3, delta);
        assertEquals(44, e4, delta);
    }

    @Test
    public void set() {
        Matrix matrix = new Matrix(new double[][]{{10,20},{33,44}});

        matrix.set(0, 0,12.0);
        assertEquals(12.0, matrix.get(0, 0), 1e-15);

    }

    @Test
    public void asArray() {
        double [][] arr  = {{12,13},{14,15},{3,4}};
        Matrix matrix = new Matrix(arr);
        double[][] result = matrix.asArray();
        assertArrayEquals(arr,result);

    }

    @Test
    public void testToString() {
        String s= "[[1.0,2.3,4.56], [12.3,  45, 21.8]]";
        s= s.replaceAll("(\\[|\\]|\\s)+","");
        String[] t = s.split("(,)+");
        for(String x:t){
            System.out.println(String.format("\'%s\'",x ));
        }

        double[]d=new double[t.length];
        for(int i=0;i<t.length;i++) {
            d[i] = Double.parseDouble(t[i]);
        }

        double arr[][]=new double[1][];
        arr[0]=d;

        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[i].length;j++){
                System.out.println(arr[i][j]);
            }
        }
    }

    @Test
    public void shape() {
    }

    @Test
    public void reshape() {
        double[][] asd = {{10,20},{33,44}};
        Matrix matrix = new Matrix(asd);
        int originalRows = matrix.rows;
        int originalCols = matrix.cols;

        int newrows = 3;
        int newcols = 2;
        Exception exception = assertThrows(RuntimeException.class, () -> matrix.reshape(newrows, newcols));

        String expectedExceptionMessage = String.format("%d x %d matrix can't be reshaped to %d x %d", originalRows, originalCols, newrows, newcols);
        assertEquals(expectedExceptionMessage, exception.getMessage());
        assertEquals(originalRows, matrix.rows);
        assertEquals(originalCols, matrix.cols);
    }

    @Test
    public void add() {
        double[][] asd1 = {{1, 2}, {3, 4}};
        double[][] asd2 = {{1, 2, 3}, {4, 5, 6}};
        double[][] asd3 = {{1, 2}, {3, 4}};
        double[][] asd4 = {{5, 6}, {7, 8}};

        Matrix matrix1 = new Matrix(asd1);
        Matrix matrix2 = new Matrix(asd2);
        Matrix matrix3 = new Matrix(asd3);
        Matrix matrix4 = new Matrix(asd4);

        assertThrows(RuntimeException.class, () -> matrix1.add(matrix2));
        Matrix result = matrix3.add(matrix4);
        double[][] expectedResult = {{6, 8}, {10, 12}};
        assertArrayEquals(expectedResult, result.asArray());
}

    @Test
    public void sub() {
        double[][] asd1 = {{1, 2}, {3, 4}};
        double[][] asd2 = {{1, 2, 3}, {4, 5, 6}};
        double[][] asd3 = {{1, 2}, {3, 4}};
        double[][] asd4 = {{5, 6}, {7, 8}};

        Matrix matrix1 = new Matrix(asd1);
        Matrix matrix2 = new Matrix(asd2);
        Matrix matrix3 = new Matrix(asd3);
        Matrix matrix4 = new Matrix(asd4);

        assertThrows(RuntimeException.class, () -> matrix1.sub(matrix2));
        Matrix result = matrix3.sub(matrix4);
        double[][] expectedResult = {{-4, -4}, {-4, -4}};
        assertArrayEquals(expectedResult, result.asArray());
    }

    @Test
    public void mul() {
        double[][] asd1 = {{1, 2}, {3, 4}};
        double[][] asd2 = {{1, 2, 3}, {4, 5, 6},{7, 8, 9}};
        double[][] asd3 = {{1, 2}, {3, 4}};
        double[][] asd4 = {{5, 6}, {7, 8}};

        Matrix matrix1 = new Matrix(asd1);
        Matrix matrix2 = new Matrix(asd2);
        Matrix matrix3 = new Matrix(asd3);
        Matrix matrix4 = new Matrix(asd4);

        assertThrows(RuntimeException.class, () -> matrix1.mul(matrix2));
        assertThrows(RuntimeException.class, () -> matrix2.mul(matrix1));
        Matrix result = matrix3.mul(matrix4);
        double[][] expectedResult = {{19, 22}, {43, 50}};
        assertArrayEquals(expectedResult, result.asArray());
    }

    @Test
    public void div() {
        double[][] asd = {{1, 2}, {3, 4}};
        double w = 2.0;

        Matrix matrix = new Matrix(asd);

        Matrix result = matrix.div(w);

        double[][] expectedData = {{0.5, 1.0}, {1.5, 2.0}};
        assertArrayEquals(expectedData, result.asArray());
    }

    @Test
    public void dot() {
        double[][] asd1 = {{1, 2}, {3, 4}};
        double[][] asd2 = {{1, 2, 3}, {4, 5, 6},{7, 8, 9}};
        double[][] asd3 = {{1, 2}, {3, 4}};
        double[][] asd4 = {{5, 6}, {7, 8}};

        Matrix matrix1 = new Matrix(asd1);
        Matrix matrix2 = new Matrix(asd2);
        Matrix matrix3 = new Matrix(asd3);
        Matrix matrix4 = new Matrix(asd4);

        assertThrows(RuntimeException.class, () -> matrix1.mul(matrix2));
        assertThrows(RuntimeException.class, () -> matrix2.mul(matrix1));
        Matrix result = matrix3.mul(matrix4);
        double[][] expectedResult = {{19, 22}, {43, 50}};
        assertArrayEquals(expectedResult, result.asArray());
    }

    @Test
    public void frobenius() {
        double[][] asd = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

        Matrix matrix = new Matrix(asd);
        double frobenius = matrix.frobenius();

        double expectedNorm = Math.sqrt( 1*1 + 2*2 + 3*3 + 4*4 + 5*5 + 6*6 + 7*7 + 8*8 + 9*9);

        assertEquals(expectedNorm, frobenius, 1e-6);

}


    @Test
    public void eye() {
        int n = 0;
        int n2 = 3;

        Matrix eye1 = Matrix.eye(n);

        assertEquals(n, eye1.rows);
        assertEquals(n, eye1.cols);

        double[][] matrixData = eye1.asArray();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j) {
                    assertEquals(1.0, matrixData[i][j], 1e-6);
                } else {
                    assertEquals(0.0, matrixData[i][j], 1e-6);
                }
            }
            Matrix eye2 = Matrix.eye(n);
            assertEquals(n, eye2.rows);
            assertEquals(n, eye2.cols);

        }
    }
    @Test
    public void testAddScalar() {
        double[][] asd = {{1, 2}, {3, 4}};
        Matrix matrix = new Matrix(asd);

        Matrix result = matrix.add(1);

        double[][] expected = {{2, 3}, {4, 5}};

        assertArrayEquals(expected, result.asArray());
    }


    @Test
    public void testSubtractScalar() {
        double[][] data = {{5, 6}, {7, 8}};
        Matrix matrix = new Matrix(data);

        Matrix result = matrix.sub(3);

        double[][] expected = {{2, 3}, {4, 5}};

        assertArrayEquals(expected, result.asArray());
    }

    @Test
    public void testMultiplyByScalar() {
        double[][] asd = {{2, 3}, {4, 5}};
        Matrix matrix = new Matrix(asd);

        Matrix result = matrix.mul(2);

        double[][] expected = {{4, 6}, {8, 10}};

        assertArrayEquals(expected, result.asArray());
    }

    @Test
    public void main() {
    }
}